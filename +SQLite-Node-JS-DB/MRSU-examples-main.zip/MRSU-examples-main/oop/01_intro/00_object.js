let cat = {
    name: "Мурзик",
    say: function () {
        console.log(`Мяу! Меня зовут ${this.name}!`);
    }
}

cat.say();
