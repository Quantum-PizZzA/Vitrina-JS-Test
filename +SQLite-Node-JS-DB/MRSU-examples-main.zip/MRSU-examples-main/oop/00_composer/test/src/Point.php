<?php
namespace Andrv\Test;

class Point
{
    public $x;
    public $y;
}
