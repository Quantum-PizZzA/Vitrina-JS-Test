<?php
namespace Andrv\Test\Functions;

function hello($user)
{
    \cli\line("Hello, $user!!!");
}