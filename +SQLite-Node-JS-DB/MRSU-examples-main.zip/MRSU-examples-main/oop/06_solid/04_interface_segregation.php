<?php
interface MyMethods
{
    public function method1();
    public function method2();
    public function method3();
    public function method4();
    public function method5();
    public function method6();
}

// Нужно реализовать ВСЕ методы интерфейса
class MyClass implements MyMethods
{
    public function method1()
    {
        // Реализация
    }

    public function method2()
    {
        // Реализация
    }

    public function method3()
    {
        // Реализация
    }

    public function method4()
    {
        // Реализация
    }

    public function method5()
    {
        // Реализация
    }

    public function method6()
    {
        // Реализация
    }
}
