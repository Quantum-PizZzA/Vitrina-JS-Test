const bond1 = { name: "James Bond", salary: 50000 };

const bond2 = { name: "James Bond", salary: 50000 };

// console.log(bond1 === bond2);

// const bond = {
//     name: 'James Bond',
//     salary: 50000,
//     raiseSalary: function(percent) {
//         this.salary *= (1 + percent / 100);
//     }
// };

// bond.raiseSalary(10);
// console.log(bond);

// const anotherBond = {
//     name: 'John Bond',
//     salary: 42000,
//     raiseSalary(percent) {
//         this.salary *= (1 + percent / 100);
//     }
// };
