<?php

echo '------ $_Server -------'.PHP_EOL;
print_r($_SERVER);

echo '------ $_GET -------'.PHP_EOL;
print_r($_GET);

echo '------ $_POST -------'.PHP_EOL;
print_r($_POST);

echo "----------------";
echo date('Y-m-d');
