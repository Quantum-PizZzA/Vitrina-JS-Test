//var a = 10;

console.log(a);

// ---------------------------------------
// if (10 > 100) {
//     var a = 10;
//  }
 
//  console.log(a);

// ---------------------------------------
// for (var i = 0; i < 3; i++) {
//     console.log(i);  // 0, 1, 2
//  }
 
//  console.log(i);  //  3
  
// ---------------------------------------
// if (10 > 1) {
//     let a = 10;
//     console.log(a);  // 10
//  }
 
//  console.log(a);   // ReferenceError
 