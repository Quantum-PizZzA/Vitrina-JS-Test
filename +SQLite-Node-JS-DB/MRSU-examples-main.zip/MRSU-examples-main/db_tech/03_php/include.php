<?php

echo "Hello from include.php!\n";

echo "a=$a\n";

function f()
{{
    echo "Message from f()\n";
}

