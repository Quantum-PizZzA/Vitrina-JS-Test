<?php
function sayHello()
{
    echo 'Hello from '.__DIR__.PHP_EOL;
}

