select * from users limit 10;
