<?php
echo 'Hello, world!' . PHP_EOL;
echo 'Привет!!!';

